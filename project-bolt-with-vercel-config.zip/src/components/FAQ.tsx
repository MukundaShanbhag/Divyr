import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleQuestion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const questions = [
    {
      question: "How does Divyr's asset division system work?",
      answer: "Divyr uses a combination of financial analysis, legal guidelines, and customizable preferences to suggest fair divisions of all types of assets. Our system accounts for factors like asset value, acquisition timing, contributions from each party, and applicable state laws."
    },
    {
      question: "When will Divyr be available?",
      answer: "We're working diligently to launch Divyr in the near future. Join our waitlist to be among the first to know when we launch and to potentially participate in our beta testing program."
    },
    {
      question: "Can Divyr replace my divorce attorney?",
      answer: "While Divyr can significantly streamline the asset division process and potentially reduce legal fees, we recommend working with a qualified attorney for legal advice. Divyr is designed to complement legal counsel, not replace it."
    },
    {
      question: "Is my information secure with Divyr?",
      answer: "Absolutely. We implement bank-level security measures to protect your personal and financial information. Your privacy is our priority, and we never share your information with third parties without your explicit consent."
    },
    {
      question: "Will Divyr work for complex asset situations?",
      answer: "Yes, Divyr is being designed to handle a wide range of assets, from simple bank accounts to complex investments, retirement accounts, real estate, businesses, and personal property. The platform will adapt to your unique financial situation."
    }
  ];

  return (
    <section id="faq" className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-12">
            Frequently Asked Questions
          </h2>

          <div className="space-y-4">
            {questions.map((item, index) => (
              <div 
                key={index} 
                className={`border rounded-lg overflow-hidden ${
                  openIndex === index ? 'border-blue-300 shadow-sm' : 'border-gray-300'
                }`}
              >
                <button
                  className="w-full px-6 py-4 text-left flex justify-between items-center focus:outline-none"
                  onClick={() => toggleQuestion(index)}
                >
                  <span className="text-lg font-medium text-gray-900">{item.question}</span>
                  {openIndex === index ? (
                    <ChevronUp className="h-5 w-5 text-blue-500" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-400" />
                  )}
                </button>
                
                <div 
                  className={`overflow-hidden transition-all duration-300 ${
                    openIndex === index ? 'max-h-96' : 'max-h-0'
                  }`}
                >
                  <div className="px-6 pb-4 text-gray-600">
                    {item.answer}
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <p className="text-gray-600 mb-4">
              Have more questions? We're here to help.
            </p>
            <a 
              href="mailto:info@divyr.com" 
              className="text-blue-600 hover:text-blue-700 font-medium"
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQ;