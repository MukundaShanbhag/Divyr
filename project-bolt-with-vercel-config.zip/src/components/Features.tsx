import React from 'react';
import { SplitSquareVertical, Shield, DollarSign, FileCheck } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <SplitSquareVertical className="h-8 w-8 text-blue-600" />,
      title: 'Equitable Division',
      description: 'Our AI-powered platform suggests fair divisions of assets based on legal precedents and financial analysis.'
    },
    {
      icon: <Shield className="h-8 w-8 text-blue-600" />,
      title: 'Reduce Conflict',
      description: 'Minimize disagreements with an impartial third-party system that focuses on fairness and transparency.'
    },
    {
      icon: <DollarSign className="h-8 w-8 text-blue-600" />,
      title: 'Save Money',
      description: 'Significantly reduce legal fees by resolving asset division issues efficiently outside the courtroom.'
    },
    {
      icon: <FileCheck className="h-8 w-8 text-blue-600" />,
      title: 'Legal Compliance',
      description: 'All suggestions comply with your jurisdiction\'s divorce laws and can be easily integrated into settlement agreements.'
    }
  ];

  return (
    <section id="benefits" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">How Divyr Helps</h2>
          <p className="text-xl text-gray-600">
            We're building a platform that makes divorce asset division fair, transparent, and less stressful.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-gray-50 p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 md:mt-24 max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-8 md:p-10 shadow-sm">
            <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">Coming Soon</h3>
            <p className="text-lg text-gray-600 mb-6">
              Divyr is currently in development. We're working hard to create a platform that will revolutionize how couples handle asset division during divorce.
            </p>
            <div className="flex justify-center">
              <a 
                href="#top" 
                className="inline-flex items-center px-6 py-3 border border-blue-600 text-blue-600 bg-white rounded-lg hover:bg-blue-50 transition-colors font-medium"
              >
                Join the Waitlist
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;