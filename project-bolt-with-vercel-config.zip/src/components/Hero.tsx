import React, { useState } from 'react';
import { Scale, CheckCircle } from 'lucide-react';

const Hero = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setError('Please enter your email');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Please enter a valid email address');
      return;
    }
    // Here you would typically send the email to your backend
    setSubmitted(true);
    setError('');
  };

  return (
    <section className="pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-8 inline-block bg-blue-100 p-2 rounded-full">
            <Scale className="h-7 w-7 text-blue-600" />
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-gray-900 mb-6">
            Fair <span className="text-blue-600">Asset Division</span> During Divorce
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-10 leading-relaxed">
            Divyr helps couples navigate the complex process of dividing assets during divorce with fairness, transparency, and minimal conflict.
          </p>
          
          <div className="max-w-md mx-auto">
            {!submitted ? (
              <form onSubmit={handleSubmit} className="mb-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  <input
                    type="email"
                    placeholder="Enter your email"
                    className={`flex-grow px-4 py-3 rounded-lg border ${error ? 'border-red-400' : 'border-gray-300'} shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent`}
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (error) setError('');
                    }}
                  />
                  <button
                    type="submit"
                    className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm whitespace-nowrap"
                  >
                    Get Updates
                  </button>
                </div>
                {error && <p className="text-red-500 text-sm mt-2 text-left">{error}</p>}
              </form>
            ) : (
              <div className="bg-green-50 rounded-lg p-4 flex items-center text-green-700 mb-4">
                <CheckCircle className="h-5 w-5 mr-2" />
                <span>Thank you! We'll keep you updated on our launch.</span>
              </div>
            )}
            <p className="text-gray-500 text-sm">
              Join our waiting list to be notified when Divyr launches.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;